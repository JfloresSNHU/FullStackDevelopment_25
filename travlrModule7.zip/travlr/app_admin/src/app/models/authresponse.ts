
export class AuthResponse {
    token!: string; // Add ! to say it will be initialized later
  }
  