module.exports.travel = function(req, res) {
    res.render('travel', { title: 'Travel Destinations' });
  };
  